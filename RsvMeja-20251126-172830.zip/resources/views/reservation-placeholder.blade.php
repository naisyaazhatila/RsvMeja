<x-app-layout>
    <div class="min-h-screen bg-ivory py-16 flex items-center justify-center">
        <div class="text-center">
            <h1 class="text-4xl font-heading font-bold text-bark-900 mb-4">Sistem Reservasi Segera Hadir</h1>
            <p class="text-gray-600">Halaman reservasi sedang dalam pengembangan.</p>
        </div>
    </div>
</x-app-layout>
